// Rompemos en funciones concisas, pequeñas, claras, de una única responsabilidad.

var getRoomCost = () => {
  switch (document.getElementById("select-room").value) {
    case "js":
      return 120;
    case "s":
      return 150;
    case "std":
    default:
      return 100;
  }
};
var getSpaCost = () => (document.getElementById("checkbox-spa").checked ? 20 : 0);
var getSizeFactor = () => document.getElementById("select-size").value;
var getNumNights = () => document.getElementById("input-nights").value;
var getParkingCost = () => document.getElementById("input-parking-nights").value * 10;

// Una función para calcular el coste total, que a su vez llama a cada una
// de las funciones individuales que hemos creado antes.
var calculateTotalCost = () => (getRoomCost() + getSpaCost()) * getSizeFactor() * getNumNights() + getParkingCost();

// Otra función que acepta como parámetro de entrada un coste y lo pinta por pantalla
var updateTotalCost = cost => {
  document.getElementById("total").innerText = "Total: " + cost.toString() + "€";
};

// Nuestro event handler será una composición con 2 funciones.
var handleCalculateClick = () => updateTotalCost(calculateTotalCost());

// Registra un event handler para el click del botón "Calcular"
document.getElementById("button-calculate").addEventListener("click", handleCalculateClick);
