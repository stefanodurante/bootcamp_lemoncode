/**
 * Práctica.
 *
 * Simulamos la estancia en un hotel, controlando los siguientes parámetros
 * y calculando el precio total de la estancia:
 * - Tipo de habitación: Standard | Junior Suite | Suite
 * - Uso del SPA: SI |NO
 * - Ocupación/Tamaño: Individual | Doble | Triple
 * - Tiempo de estancia: Número de noches
 * - Parking: Numero de noches
 *
 * Con estos datos solicitados al usuario, deberemos mostrar el
 * precio total de la estancia.
 */

function calculateStay() {
  // Variable donde vamos a ir calculando el coste de la habitación.
  var roomCost = 0;

  // Obtenemos tipo de habitación y actualizamos coste.
  var roomType = document.getElementById("select-room").value;
  switch (roomType) {
    case "js":
      roomCost = 120;
      break;
    case "s":
      roomCost = 150;
      break;
    case "std":
    default:
      roomCost = 100;
      break;
  }

  // Obtenemos uso del SPA y actualizamos coste.
  var spa = document.getElementById("checkbox-spa").checked;
  roomCost += spa ? 20 : 0;

  // Obtenemos el tamaño u ocupación y actualizamos coste.
  var roomSizeFactor = document.getElementById("select-size").value;
  roomCost *= roomSizeFactor;

  // Obtenemos número de noches y actualizamos coste.
  var nights = document.getElementById("input-nights").value;
  roomCost *= nights;

  // Obtenemos uso del Parking y actualizamos coste.
  var parkingNights = document.getElementById("input-parking-nights").value;
  roomCost += parkingNights * 10;

  // Actualizamos el total por pantalla.
  document.getElementById("total").innerText = "Total: " + roomCost.toString() + "€";
}

// Registra un event handler para el click del botón "Calcular"
document.getElementById("button-calculate").addEventListener("click", calculateStay);
