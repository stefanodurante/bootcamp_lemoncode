// Pequeños ajustes son todavía posibles.
var roomPrices = {
  std: 100,
  js: 120,
  s: 150,
};

var getRoomCost = () => roomPrices[document.getElementById("select-room").value];
var getSpaCost = () => (document.getElementById("checkbox-spa").checked ? 20 : 0);
var getSizeFactor = () => document.getElementById("select-size").value;
var getNumNights = () => document.getElementById("input-nights").value;
var getParkingCost = () => document.getElementById("input-parking-nights").value * 10;

// Una función para calcular el coste total, que a su vez llama a cada una
// de las funciones individuales que hemos creado antes.
var calculateTotalCost = () => (getRoomCost() + getSpaCost()) * getSizeFactor() * getNumNights() + getParkingCost();

// Otra función que acepta como parámetro de entrada un coste y lo pinta por pantalla
var updateTotalCost = cost => {
  document.getElementById("total").innerText = "Total: " + cost.toString() + "€";
};

// Nuestro event handler será una composición con 2 funciones.
var handleCalculateStay = () => updateTotalCost(calculateTotalCost());

// Registra nuestro event handler para cada input, de modo que se actualize el precio
// en vivo. El botón Calcular realmente ya no sería necesario.
document.getElementById("button-calculate").addEventListener("click", handleCalculateStay);
document.getElementById("select-room").addEventListener("change", handleCalculateStay);
document.getElementById("checkbox-spa").addEventListener("change", handleCalculateStay);
document.getElementById("select-size").addEventListener("change", handleCalculateStay);
document.getElementById("input-nights").addEventListener("change", handleCalculateStay);
document.getElementById("input-parking-nights").addEventListener("change", handleCalculateStay);
