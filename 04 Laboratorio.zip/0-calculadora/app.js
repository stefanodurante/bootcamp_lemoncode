// 4 funciones para cada tipo de operacion.
var sum = (a, b) => a + b;
var sub = (a, b) => a - b;
var mul = (a, b) => a * b;
var div = (a, b) => a / b;

// Nos creamos funciones de ayuda para extraer Operando A y B.
var getOpA = () => parseInt(document.getElementById("opA").value);
var getOpB = () => parseInt(document.getElementById("opB").value);

// También una función de ayuda para pintar el resultado.
var showResult = result => (document.getElementById("res").innerText = isNaN(result) ? "Error" : result);

// Finalmente enganchamos los eventos de click de cada botón.
document.getElementById("button-sum").addEventListener("click", () => showResult(sum(getOpA(), getOpB())));
document.getElementById("button-sub").addEventListener("click", () => showResult(sub(getOpA(), getOpB())));
document.getElementById("button-mul").addEventListener("click", () => showResult(mul(getOpA(), getOpB())));
document.getElementById("button-div").addEventListener("click", () => showResult(div(getOpA(), getOpB())));
