// 4 funciones para cada tipo de operacion + 1 extra para
// la operación igual, que simplemente devuelve su entrada.
var sum = (a, b) => a + b;
sum.opSymbol = "+";
var sub = (a, b) => a - b;
sub.opSymbol = "-";
var mul = (a, b) => a * b;
mul.opSymbol = "*";
var div = (a, b) => a / b;
div.opSymbol = "/";
var eq = x => x;
eq.opSymbol = "=";

// Nos creamos una funcion de ayuda para extraer Operando.
var getOperand = () => parseInt(document.getElementById("input-operand").value);
var setOperand = value => (document.getElementById("input-operand").value = value);

// También una función de ayuda para pintar el resultado.
var showResult = result => {
  document.getElementById("result").innerText = result;
  console.log(result);
};

// Y una función de ayuda para pintar la descripción de la operación.
var showDescription = step => (document.getElementById("description").innerText += step);
var clearDesription = () => (document.getElementById("description").innerText = "");

// **********
// Comienza el algoritmo principal, haciendo uso de las funciones planteadas
// más arriba.

// Variables para acarrear y almacenar.
var pendingOperation;
var result;

// Y una función para hacernos los cálculos parciales.
var calculate = operation => {
  // Paso 1. Obtén el operando actual.
  var operand = getOperand();

  // Paso 2. Calcula la operación pendiente, si aplica.
  result = pendingOperation ? pendingOperation(result, operand) : operand;

  // Paso 3. Actualiza la descripcion de la operacion.
  // Almacena la oepracion actual como operación pendiente.
  showDescription(operand + operation.opSymbol);
  pendingOperation = operation;
};

// Funcion clear para resetear la calculadora.
const clear = () => {
  pendingOperation = undefined;
  result = undefined;
  showResult("");
  setOperand(null);
  clearDesription();
};

// **********

// Finalmente enganchamos los eventos de click de cada botón.
document.getElementById("button-sum").addEventListener("click", () => calculate(sum));
document.getElementById("button-sub").addEventListener("click", () => calculate(sub));
document.getElementById("button-mul").addEventListener("click", () => calculate(mul));
document.getElementById("button-div").addEventListener("click", () => calculate(div));
document.getElementById("button-result").addEventListener("click", () => {
  calculate(eq);
  showResult(result);
  setOperand(result);
});
document.getElementById("button-clear").addEventListener("click", clear);
