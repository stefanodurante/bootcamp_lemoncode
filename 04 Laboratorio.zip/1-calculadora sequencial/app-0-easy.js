// 4 funciones para cada tipo de operacion.
var sum = (a, b) => a + b;
var sub = (a, b) => a - b;
var mul = (a, b) => a * b;
var div = (a, b) => a / b;

// Nos creamos una funcion de ayuda para extraer Operando.
var getOperand = () => parseInt(document.getElementById("input-operand").value);
var setOperand = value => (document.getElementById("input-operand").value = value);

// También una función de ayuda para pintar el resultado.
var showResult = result => {
  document.getElementById("result").innerText = result;
  console.log(result);
};

// Y una función de ayuda para pintar la descripción de la operación.
var showDescription = step => (document.getElementById("description").innerText += step);
var clearDesription = () => (document.getElementById("description").innerText = "");

// Y una función para calcular un resultado, dados 2 operandos y una operación.
var calculate = (a, b, operation) => {
  switch (operation) {
    case "+":
      return sum(a, b);
    case "-":
      return sub(a, b);
    case "*":
      return mul(a, b);
    case "/":
      return div(a, b);
    case "=":
      return a; // a es result cuando lo llamamos desde calculatePartial.
    default:
      console.log("Invalid operation ", operation);
  }
};

// **********
// Comienza el algoritmo principal, haciendo uso de las funciones planteadas
// más arriba.

// Variables para acarrear y almacenar.
var pendingOperation;
var result;

// Y una función para hacernos los cálculos parciales.
var calculatePartial = operation => {
  // Paso 1. Obtén el operando actual.
  var operand = getOperand();

  // Paso 2. Calcula la operación pendiente, si aplica.
  if (pendingOperation) {
    result = calculate(result, operand, pendingOperation);
  } else {
    result = operand;
  }

  // Paso 3. Actualiza la descripcion de la operacion.
  // Almacena la oepracion actual como operación pendiente.
  showDescription(operand + operation);
  pendingOperation = operation;
};

// Funcion clear para resetear la calculadora.
const clear = () => {
  pendingOperation = undefined;
  result = undefined;
  showResult("");
  setOperand(null);
  clearDesription();
};

// **********

// Finalmente enganchamos los eventos de click de cada botón.
document.getElementById("button-sum").addEventListener("click", () => calculatePartial("+"));
document.getElementById("button-sub").addEventListener("click", () => calculatePartial("-"));
document.getElementById("button-mul").addEventListener("click", () => calculatePartial("*"));
document.getElementById("button-div").addEventListener("click", () => calculatePartial("/"));
document.getElementById("button-result").addEventListener("click", () => {
  calculatePartial("=");
  showResult(result);
  setOperand(result);
});
document.getElementById("button-clear").addEventListener("click", clear);
