const ClientListBusiness = require("./client-list-business");

// index.js 

window.onload = function() {
    ClientListBusiness.printClientsAccounts();
};

// client-list-business.js



// client-business.js



// account-business.js



// style-business.js



// data-business.jsDataBusiness