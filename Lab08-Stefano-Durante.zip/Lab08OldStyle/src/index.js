// index.js 

window.onload = function() {
    printClientsAccounts();
};

// client-list-business.js



// client-business.js



// account-business.js



// style-business.js