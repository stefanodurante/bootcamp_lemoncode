console.log('hola');

document.getElementById("avatar_img").src = "https://img.icons8.com/officel/2x/avatar.png";
document.getElementById("input_last_name").value = "Durante";
document.getElementById("input_name").value = "Stefano";